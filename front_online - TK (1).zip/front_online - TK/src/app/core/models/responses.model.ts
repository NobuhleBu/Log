export interface ErrorResponse {
    code: number,
    message: string
}

export interface SuccessResponse {
    code: number,
    message: string
}