import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technician',
  templateUrl: './technician.component.html',
  styleUrls: ['./technician.component.css']
})
export class TechnicianComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
