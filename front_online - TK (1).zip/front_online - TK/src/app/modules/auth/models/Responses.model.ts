export interface AuthenticateResponse {
  accessToken: string;
  refreshToken: string;
  id: string;
}

export interface RegisterResponse {

}
